import javax.xml.soap.Node;

public class Rope {

    RopeNode root;
     Rope left;
     Rope right;
     int data;

    public Rope() {
        root = new RopeNode("");
    }

    Rope (int data){
        this.data=data;
        right=null;
        left=null;
    }

    public void concat(Rope s1, Rope s2) {
        Rope newroot = new Rope(0);
        newroot.left = s1;
        newroot.right = s2;
        newroot.data = updateDataNode(newroot);
    }

    public int updateDataNode(Rope r){
        r=r.left;
        int u=r.data;
        while(r.right!=null){
            r=r.right;
            u+=r.data;
        }
        return u;
    }
}




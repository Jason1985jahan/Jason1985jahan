import javax.xml.soap.Node;
import java.util.LinkedList;
import java.util.Queue;

public class Rope {

    RopeNode root;
     Rope left;
     Rope right;
     int data;

    public Rope() {
        root = new RopeNode("");
    }

    Rope (int data){
        this.data=data;
        right=null;
        left=null;
    }

    public void concat(Rope s1, Rope s2) {
        Rope newroot = new Rope(0);
        newroot.left = s1;
        newroot.right = s2;
        newroot.data = updateDataNode(newroot);
    }

    public int updateDataNode(Rope r){
        r=r.left;
        int u=r.data;
        while(r.right!=null){
            r=r.right;
            u+=r.data;
        }
        return u;
    }
    public static void levelordernumbering(Rope root){
        Rope current = new Rope(0);
        if (root!= null){
            Queue<Rope> q1 = new LinkedList<>();
            Queue<Rope> q2 = new LinkedList<>();
            q1.add(root);
            while (!q1.isEmpty() || !q2.isEmpty()){
                while (!q1.isEmpty()){
                    current = q1.poll();
                    //System.out.print(current.number + " ");
                    if (current.left != null)
                        q2.add(current.left);
                    if (current.right != null)
                        q2.add(current.right);
                }
                while (!q2.isEmpty()) {
                    current = q2.poll();
                    //System.out.print(current.number + " ");
                    if (current.left != null)
                        q1.add(current.left);
                    if (current.right != null)
                        q1.add(current.right);
                }

            }
        }
    }
}




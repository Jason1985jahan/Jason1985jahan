import javax.xml.soap.Node;

public class RopeNode {
    public int value;
    RopeNode left;
    RopeNode right;
    String data;

    public RopeNode(String data)
    {
        this.data = data;
        left = null;
        right = null;
        value = data.length();
    }

    public RopeNode() {

    }
}

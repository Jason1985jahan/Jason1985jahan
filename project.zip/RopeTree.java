import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class RopeTree {
    String []Str =new String[100];
    Queue<Rope> q=new LinkedList<>();
    Queue<Rope> N1=new LinkedList<>();
    Queue<Rope> N2=new LinkedList<>();

     static ArrayList<String> p=new ArrayList<>();
     static ArrayList<Integer> r=new ArrayList<>();
     static  ArrayList<Rope> OddSubRope=new ArrayList<>();
     static  ArrayList<Rope> EvenSubRope=new ArrayList<>();

   // String []inputsStr=new String[1000];
    int NumInput=0;
    static class Rope{
        String str;
        int data,number;
        Rope right,left;
        Rope (int data){
            this.data=data;
            right=null;
            left=null;
        }
        //leaf
        Rope(String s){
            this.str=s;
            this.data=s.length();
        }
    }
    Rope []ArrayRoots= new Rope[100];
    int ArrayR=0;
    public void New(String s){
        separateToSpace(s);
        System.out.println(":)");
        CreateRope();
    }
    public void CreateRope(){
        if(NumInput==1)
          ArrayRoots[ArrayR++] = createAloneNode(Str[0]);

        else if(NumInput==2)
           ArrayRoots[ArrayR++] = create2Nodes(Str);

        else if(NumInput==3){
           int u=Str[0].length()+Str[1].length();
           ArrayRoots[ArrayR++]= create3Nodes(create2Nodes(Str),u,2,Str);
        }
        else{
           NumInput = 2*NumInput-1;
           Rope root=createEmptyTree(NumInput);
           CreateMore3Nodes(root,0);
           r.clear();
        }
    }
    public void separateToSpace(String s){
        int m=0,o;
        for(int i=0; i<s.length() ;i++){
            o=i;
            while(i<s.length()-1 && s.charAt(i)!=' ')
                i++;
            if(i<=s.length()) {
                boolean j=false;
                while(s.charAt(i)==' ') {
                    i++;
                    j=true;
                }
                if(i==s.length()-1){
                    if(j) {
                        Str[m++] = s.substring(o, i);
                        NumInput = m;
                    }
                    else {
                        Str[m++] = s.substring(o, i+1);
                        NumInput = m;
                    }
                }
                else {
                    Str[m++] = s.substring(o, i);
                    NumInput = m;
                }
                if(j) {
                    i--;
                }
            }
            else
                break;
        }
        return;
    }
    public Rope create3Nodes(Rope Rb, int u, int index, String []s){
      Rope j=new Rope(s[index]);
      Rope R=new Rope(u);
      R.left=Rb;
      R.right=j;
      return R;
    }
    public Rope create2Nodes(String []s){
        Rope r1=new Rope(s[0]);
        Rope r2=new Rope(s[1]);
        Rope R=new Rope(s[0].length());
        R.left=r1; R.right=r2;
        return R;
    }
    public Rope createAloneNode(String s){
        Rope a=new Rope(s);
        Rope r=new Rope(s.length());
        r.left=a;
        return r;
    }
    public Rope createEmptyTree(int sum){
        Rope root=new Rope(0); root.str="root";
        Rope leftNode=new Rope(0);
        Rope rightNode =new Rope(0);
        root.left=leftNode;   root.right=rightNode;
        sum-=3;  leftNode.str="leaf";    rightNode.str="leaf";
        q.add(leftNode); q.add(rightNode);
        while(sum!=0){
            Rope e=q.peek(); q.poll();
            e.str="null";
            Rope LN=new Rope(0);  LN.str="leaf";
            Rope RN = new Rope(0);
            e.left=LN; sum--;
            if(sum!=0) {
                e.right=RN;
                RN.str="leaf";
                sum--;
            }
            q.add(LN); q.add(RN);
        }
        while (!q.isEmpty())
            q.poll();
        return root;
    }
    public void preorderRope(Rope root){
        if(root!=null){
            if(root.str!=null) {
                System.out.print(root.str);
                p.add(root.str);
            }
            preorderRope(root.left);
            preorderRope(root.right);
        }
    }
    int d;
    public char indexSearch(Rope r,int ch){
        Rope j=r;
        while(j.str==null){
            if(j.data>ch)
                j=j.left;
            else {
                ch=ch-j.data;
                j=j.right;
            }
        }
        d=ch;
        return j.str.charAt(ch);
    }
    public Rope indexSearchSplit(Rope r,int ch){
        Rope j=r;
        while(j.str==null){
            if(j.data>ch)
                j=j.left;
            else {
                ch=ch-j.data;
                j=j.right;
            }
        }
        return j;
    }
    public void split(int ch,int s,int sum) {
        int t,u,b;
        numberingNodes(s,sum);
        while(!N1.isEmpty())
            N2.add(N1.poll());
        indexSearch(N2.peek(), ch);
        Rope r=indexSearchSplit(N2.peek() ,ch);
        if(r.number%2==0){
            u=r.number;
            t=u;
            while(t%2!=1)
                t/=2;
            t/=2;
            Rope e=N2.poll();
            //find father node
            while(e.number!=t) {
                e = N2.poll();
                N2.add(e);
            }
            //separate Two Leaves
            Rope leftR=new Rope(r.str.substring(0,d));
            r.str=r.str.substring(d);
            int i=e.number ,m=0;
            while(i!=1){
                if(i==3)
                    m=3;
                else if(i==2)
                    m=2;
                while (e.number!=i) {
                    e = N2.poll();
                    N2.add(e);
                }
                EvenSubRope.add(e);
                i/=2;
            }
            for(int j=0 ;j<EvenSubRope.size() ;j++) {
                if (m == 2) {
                    if (j == 0) {
                        Rope q2= EvenSubRope.get(j).left;
                        EvenSubRope.get(j).left = null;
                        Rope q = new Rope(EvenSubRope.get(j).data); EvenSubRope.add(q);
                        q.right = leftR;
                        q.left = q2;
                    } else {
                        Rope l=EvenSubRope.get(j).left;
                        Rope q = new Rope(EvenSubRope.get(j).data);
                        q.left=l; q.right=EvenSubRope.get(EvenSubRope.size()-1);
                        EvenSubRope.remove(EvenSubRope.size()-1);
                    }
                }
                else if(m==3){
                    if(j==0){
                        EvenSubRope.get(j).right = null;
                        EvenSubRope.get(j).right=leftR;
                    }
                }
            }
        }
        else {
            u=r.number;
            t=u;
            while(t%2!=0)
                t/=2;
            t/=2;
        }
    }
    public void CreateMore3Nodes(Rope root,int index){
        if(root!=null) {
            CreateMore3Nodes(root.left, r.size());
            if (root.str.equals("leaf")) {
                root.str = Str[index];
                root.data = Str[index].length();
                r.add(index);
            } else if (root.str.equals("root")) {
                root.data = updateDataNode(root);
                System.out.println(root.data + " ");
                root.str = null;
                ArrayRoots[ArrayR++] = root;
            } else {
                root.str = null;
                root.data = updateDataNode(root);
                System.out.println(root.data + " ");
            }
            CreateMore3Nodes(root.right, r.size());
        }
    }
    public void concat(Rope a,Rope b){
        Rope newRoot=new Rope(0); int i=0;
        newRoot.right=b;
        newRoot.left=a;
        newRoot.data=updateDataNode(newRoot);
        while (ArrayRoots[i]!=null){
            if(ArrayRoots[i]==a)
                ArrayRoots[i]=newRoot;
            if(ArrayRoots[i]==b)
                ArrayRoots[i] = createAloneNode("----");
          i++;
        }
    }
    public int updateDataNode(Rope r){
        r=r.left;
        int u=r.data;
        while(r.right!=null){
            r=r.right;
            u+=r.data;
        }
        return u;
    }
    public void numberingNodes(int a,int sum){
        Rope r=ArrayRoots[a-1]; int i=1; Rope f;
        r.number=1;
        N1.add(r);
        while(i<=sum){
            f=N1.poll();
            N2.add(f);
            if(f.left!=null) {
                f.left.number=i+1;
                N1.add(f.left);
                i++;
            }
            if(i<=sum){
                if(f.right!=null) {
                    f.right.number=i+1;
                    N1.add(f.right);
                    i++;
                }
                else
                    i++;
            }
        }
    }
    public void status(){
        int i=0;
        while (ArrayRoots[i]!=null) {
            preorderRope(ArrayRoots[i]);
            System.out.println();
            i++;
        }
    }
    public static void main(String[] args) throws FileNotFoundException {
        String input=new Scanner(System.in).nextLine();
        RopeTree r=new RopeTree();
        while (input.length()!=0) {
            //New
            if (input.equals("new")) {
                input = new Scanner(System.in).nextLine();
                r.New(input);
            }
            //Status
            else if (input.equals("Status")) {
                r.status();
            }
            //index
            else if(input.substring(0,5).equals("index")) {
                r.separateToSpace(input);
                int m=Integer.parseInt(r.Str[1].trim());
                int n=Integer.parseInt(r.Str[2].trim());
                System.out.println(r.indexSearch(r.ArrayRoots[m-1],n));
            }
            //concat
            else if(input.substring(0,6).equals("concat")){
                r.separateToSpace(input);
                int m=Integer.parseInt(r.Str[1].trim());
                int n=Integer.parseInt(r.Str[2].trim());
                r.concat(r.ArrayRoots[m-1],r.ArrayRoots[n-1]);
                System.out.println("done");
            }
            //autoComplete
            else if(input.substring(0,12).equals("autocomplete")){
                char c=input.charAt(13);
                System.out.println(c);
                TrieTree t=new TrieTree();
                t.readFromFile();
                r.New(t.autoComplete(c));
            }
            input=new Scanner(System.in).nextLine();
        }
        System.out.println("oops :-(");
    }
}
